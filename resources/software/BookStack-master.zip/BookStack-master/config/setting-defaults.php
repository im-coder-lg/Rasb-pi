<?php

/**
 * The defaults for the system settings that are saved in the database.
 */
return [

    'app-editor' => 'wysiwyg'

];