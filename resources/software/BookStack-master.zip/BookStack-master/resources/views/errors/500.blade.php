@extends('base')

@section('content')

    <div class="container">
        <h1 class="text-muted">An Error Occurred</h1>
        <p>{{ $message }}</p>
    </div>

@stop