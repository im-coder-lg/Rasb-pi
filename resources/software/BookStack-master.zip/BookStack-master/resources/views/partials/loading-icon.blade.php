<div class="loading-container">
    <div></div>
    <div></div>
    <div></div>
</div>