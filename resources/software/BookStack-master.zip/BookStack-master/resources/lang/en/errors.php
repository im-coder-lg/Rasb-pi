<?php

return [

    /**
     * Error text strings.
     */

    // Pages
    'permission' => 'You do not have permission to access the requested page.',
    'permissionJson' => 'You do not have permission to perform the requested action.'
];