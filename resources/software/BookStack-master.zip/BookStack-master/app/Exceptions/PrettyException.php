<?php namespace BookStack\Exceptions;

use Exception;

class PrettyException extends Exception {}