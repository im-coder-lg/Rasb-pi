<?php namespace BookStack\Exceptions;


class AuthException extends PrettyException {}