<?php

namespace BookStack\Events;

abstract class Event
{
    //
}
